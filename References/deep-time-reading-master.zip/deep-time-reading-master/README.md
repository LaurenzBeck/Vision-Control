Deep time reading
-----------------

Using deep learning to tell time from images of clocks with Tensorflow.

Please see the entire documentation here:
<https://felixduvallet.github.io/blog/deep.time/>

Contributions are welcome via issues and pull requests. If this code is helpful to you, please star the repository.

We build the bootloaders for the A-Star 328PB using WinAVR-201001110.
